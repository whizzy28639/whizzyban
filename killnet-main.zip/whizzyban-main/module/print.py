primt("hello")
primt("B.W")
